package com.stockmarkComp.companyStockMarket.bean;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "companyDetails")
public class CompanyDetails 
{

	private String compCode;
	private String compName;
	private int stckAvble;
	private String updateDate;
	private String updateTime;
	private String compCEO;
	private String compTurnOver;
	private String compWebsite;
	private String maxStckPrice;
	private String minStckPrice;
	private String avegStckPrice;
	
	public String getCompCode() {
		return compCode;
	}
	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public int getStckAvble() {
		return stckAvble;
	}
	public void setStckAvble(int stckAvble) {
		this.stckAvble = stckAvble;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getCompCEO() {
		return compCEO;
	}
	public void setCompCEO(String compCEO) {
		this.compCEO = compCEO;
	}
	public String getCompTurnOver() {
		return compTurnOver;
	}
	public void setCompTurnOver(String compTurnOver) {
		this.compTurnOver = compTurnOver;
	}
	public String getCompWebsite() {
		return compWebsite;
	}
	public void setCompWebsite(String compWebsite) {
		this.compWebsite = compWebsite;
	}
	public String getMaxStckPrice() {
		return maxStckPrice;
	}
	public void setMaxStckPrice(String maxStckPrice) {
		this.maxStckPrice = maxStckPrice;
	}
	public String getMinStckPrice() {
		return minStckPrice;
	}
	public void setMinStckPrice(String minStckPrice) {
		this.minStckPrice = minStckPrice;
	}
	public String getAvegStckPrice() {
		return avegStckPrice;
	}
	public void setAvegStckPrice(String avegStckPrice) {
		this.avegStckPrice = avegStckPrice;
	}

}
