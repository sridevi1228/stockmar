package com.stockmarkComp.companyStockMarket.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.stockmarkComp.companyStockMarket.bean.CompanyDetails;


public interface CompanyStockMarketRepository extends MongoRepository<CompanyDetails, Integer>
{

	@Query("{compCode : ?0}")
	CompanyDetails getCompanyByCode(String compCode);

	@Query(value = "{'compCode' : ?0}", delete = true)
	void deleteCompanyByCode(String compCode);
	
}
