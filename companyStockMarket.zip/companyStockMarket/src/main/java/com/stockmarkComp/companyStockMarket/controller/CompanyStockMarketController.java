package com.stockmarkComp.companyStockMarket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockmarkComp.companyStockMarket.bean.CompanyDetails;
import com.stockmarkComp.companyStockMarket.services.CompanyStockMarketServices;


@RestController
@RequestMapping("companyDetails")
@CrossOrigin(origins = "*", maxAge = 3600 )
public class CompanyStockMarketController 
{

	@Autowired
	CompanyStockMarketServices companyService;

	@GetMapping("/getAll")
	public ResponseEntity<?> getAllComp() {
		try {
			List<CompanyDetails> listofCompanies = companyService.getAllComp();
			return new ResponseEntity<>(listofCompanies, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("/addCompany")
	public ResponseEntity<?> addComp(@RequestBody CompanyDetails company) {
		try {
			if (company != null) {
				companyService.addComp(company);
				return new ResponseEntity<>(HttpStatus.CREATED);
			} else {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/getCompany/{companyCode}")
	public ResponseEntity<?> getCompByCmnyCode(@PathVariable String companyCode) {
		try {
			CompanyDetails company = companyService.getCompByCode(companyCode);
			return new ResponseEntity<>(company, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/deleteCompany/{companyCode}")
	public ResponseEntity<?> deleteComp(@PathVariable String companyCode) {
		try {
			if (companyCode != null) {
				companyService.deleteCompByCode(companyCode);
				return new ResponseEntity<>(HttpStatus.CREATED);
			} else {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/updateStockPrice")
	public ResponseEntity<?> updStockPrice(@RequestBody CompanyDetails company) {
		try {
			if (company != null) {
				CompanyDetails updatedComp = companyService.updStockPrice(company);
				return new ResponseEntity<>(updatedComp, HttpStatus.CREATED);
			} else {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
}
