package com.stockmarkComp.companyStockMarket.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.stockmarkComp.companyStockMarket.bean.CompanyDetails;
import com.stockmarkComp.companyStockMarket.repositories.CompanyStockMarketRepository;

@Component
@Service
public class CompanyStockMarketServices 
{
    @Autowired
	CompanyStockMarketRepository compRepo;
    
    public List<CompanyDetails> getAllComp()
	{
		List<CompanyDetails> listOfCompany = compRepo.findAll();
		return listOfCompany;
	}
	
	public CompanyDetails getCompByCode(String companyCode)
	{
		CompanyDetails company = compRepo.getCompanyByCode(companyCode);
		return company;
	}
	
	public String addComp(CompanyDetails company)
	{
		compRepo.save(company);
		return "Added Successfully";
	}
	
	public String deleteCompByCode(String companyCode)
	{
		compRepo.deleteCompanyByCode(companyCode);
		return "Deleted Successfully";
	}
	
	
	public CompanyDetails updStockPrice(CompanyDetails company)
	{
		CompanyDetails comp = compRepo.getCompanyByCode(company.getCompCode());
		if(comp != null)
		{
			compRepo.deleteCompanyByCode(comp.getCompCode());;
			compRepo.save(company);
		}
		return comp;
	}
}
