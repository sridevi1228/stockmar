package com.stockmarkComp.companyStockMarket.serviceTest;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.stockmarkComp.companyStockMarket.bean.CompanyDetails;
import com.stockmarkComp.companyStockMarket.repositories.CompanyStockMarketRepository;
import com.stockmarkComp.companyStockMarket.services.CompanyStockMarketServices;


@RunWith(MockitoJUnitRunner.class)
public class CompanyStockMarketServicesTest 
{

	@InjectMocks
	public CompanyStockMarketServices compServices;
	
	@Mock
    CompanyStockMarketRepository companyRepository;
	
	@Test
	public void getAllCompTest()
	{
		Object obj = compServices.getAllComp();
		Assert.assertNotNull(obj);
	}
	
	@Test
	public void getCompByCodeTest()
	{
		String companyCode = "COMCODE2";
		
		Object obj = compServices.getCompByCode(companyCode);
		Assert.assertNotNull(obj);
	}
	
	@Test
	public void addCompTest()
	{
		Object obj = compServices.addComp(getCompanyDetails());
		Assert.assertNotNull(obj);
	}
	
	@Test
	public void deleteCompByCodeTest()
	{
		String companyCode = "COMCODE2";
		
		Object obj = compServices.deleteCompByCode(companyCode);
		Assert.assertNotNull(obj);
	}
	
	@Test
	public void updStckPriceTest()
	{
		Object obj = compServices.updStockPrice(getCompanyDetails());
		Assert.assertNotNull(obj);
	}
	
	
	public CompanyDetails getCompanyDetails()
	{
		CompanyDetails comp = new CompanyDetails();
		
		comp.setCompCode("COMPCODE12");
		comp.setCompName("Company12");
		comp.setCompTurnOver("30Cr");
		comp.setCompWebsite("www.company12.com");
		comp.setUpdateTime("20:23");
		comp.setUpdateDate("20/12/2022");
		comp.setStckAvble(12);
		comp.setMinStckPrice("1000.33");
		comp.setMaxStckPrice("3000.45");
		comp.setAvegStckPrice("2000");
		
		return comp;
	}

}
