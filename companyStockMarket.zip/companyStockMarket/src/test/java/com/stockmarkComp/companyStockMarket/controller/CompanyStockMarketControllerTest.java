package com.stockmarkComp.companyStockMarket.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.stockmarkComp.companyStockMarket.bean.CompanyDetails;
import com.stockmarkComp.companyStockMarket.services.CompanyStockMarketServices;


@RunWith(MockitoJUnitRunner.class)
public class CompanyStockMarketControllerTest 
{

	@InjectMocks
	public CompanyStockMarketController compSMController;
	
	@Mock
	public CompanyStockMarketServices compSMServices;
	
	
	@Test
	public void getAllTest()
	{
		Object obj = compSMController.getAllComp();
		Assert.assertNotNull(obj);
	}
	
	@Test
	public void addCompanyTest()
	{
		Object obj = compSMController.addComp(getCompanyPOJO());
		Assert.assertNotNull(obj);
	}
	
	@Test
	public void getCompanyByCmnyCodeTest()
	{
		String companyCode = "COMCODE2";
		
		Object obj = compSMController.getCompByCmnyCode(companyCode);
		Assert.assertNotNull(obj);
	}
	
	@Test
	public void deleteCompany()
	{
		String companyCode = "COMCODE2";
		
		Object obj = compSMController.deleteComp(companyCode);
		Assert.assertNotNull(obj);
	}
	
	@Test
	public void updateStockPriceTest()
	{
		Object obj = compSMController.updStockPrice(getCompanyPOJO());
		Assert.assertNotNull(obj);
	}
	
	public CompanyDetails getCompanyPOJO()
	{
		CompanyDetails comp = new CompanyDetails();
		
		comp.setCompCode("COMPCODE12");
		comp.setCompName("Company12");
		comp.setCompTurnOver("30Cr");
		comp.setCompWebsite("www.company12.com");
		comp.setUpdateTime("20:23");
		comp.setUpdateDate("20/12/2022");
		comp.setStckAvble(12);
		comp.setMinStckPrice("1000.33");
		comp.setMaxStckPrice("3000.45");
		comp.setAvegStckPrice("2000");
		
		return comp;
	}

}
